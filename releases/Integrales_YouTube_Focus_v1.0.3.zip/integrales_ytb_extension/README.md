# Intégrales — YouTube Focus

Extension Chromium Manifest V3 (version 1.0.3) pensée pour Arc sous Windows. Arc indique officiellement que l’application Windows cessera de fonctionner le **22 décembre 2026** ; le code garde donc des API Chromium standard afin de faciliter une migration éventuelle vers Dia si tu le décides. Voir [l’annonce officielle d’Arc](https://arc.net/). Lorsqu'une vidéo YouTube est ouverte, l'extension intercepte la navigation avant l'affichage du lecteur, analyse le sujet avec Gemini et, si le lien avec une matière autorisée n'est pas établi, remplace la page par une interface d'intégrale.

## Fonctionnalités

- Interception des vidéos depuis recommandations, recherche, Shorts, liens directs, liens partagés, nouveaux onglets, navigation par URL et lecteurs YouTube intégrés (`youtube-nocookie.com`).
- Blocage réseau par défaut des flux vidéo YouTube (`googlevideo.com`), avec autorisation limitée à un onglet et à la vidéo validée. Le contexte de la vidéo est conservé côté service worker ; les paramètres de l’URL de la page d’intégrale ne peuvent pas choisir une vidéo à débloquer.
- Détection limitée aux URL YouTube / youtu.be. Les autres plateformes vidéo ne sont pas touchées.
- Analyse Gemini progressive : titre d'abord, métadonnées et transcription disponible si le titre ne suffit pas.
- Les vidéos hors programme ou incertaines restent bloquées.
- L’intégrale et le bouton de recours apparaissent dès l’ouverture de la page, pendant que l’analyse automatique se déroule.
- Les requêtes Gemini et les récupérations de métadonnées ont un délai maximal ; une API qui ne répond pas ne laisse pas l’utilisateur sans interface.
- Bouton « Solution » pour remplacer l'énoncé par la correction intégrée dans la page.
- Bouton « Trouver une autre intégrale » avec tirage aléatoire parmi les 100 exercices.
- Chatbot de recours Gemini, accessible immédiatement, qui déverrouille uniquement la vidéo contestée si la justification est acceptée.
- Paramètres locaux pour la clé API et le modèle Gemini. Aucune clé n'est incluse dans les sources.
- Les 100 énoncés et 100 solutions sont rendus en images PNG pour éviter d'ouvrir un lecteur PDF.

## Vérifications locales

Les tests automatisés couvrent les URL YouTube et YouTube-nocookie, l’absence de déblocage sans validation, le contexte de vidéo conservé côté service worker, le refus et l’acceptation de Gemini simulés, le déblocage à usage unique et la présence des 100 paires d’images. Depuis la racine du projet, lance `node tests/smoke.test.js`.

## Installation dans Arc sous Windows

1. Télécharge ou clone le dépôt, puis décompresse le ZIP s'il y en a un.
2. Dans Arc, ouvre la page des extensions (`arc://extensions` ou `chrome://extensions`).
3. Active le **Mode développeur**.
4. Clique sur **Charger l'extension non empaquetée** et choisis le dossier qui contient `manifest.json`.
5. Ouvre les paramètres de l'extension depuis son icône et configure ta clé API Gemini.
6. Utilise « Tester la connexion », puis « Enregistrer ».

Si Arc utilise une URL de gestion différente, ouvre le gestionnaire d'extensions depuis le menu du navigateur.

## Matières autorisées par défaut

- Mathématiques
- Maths expertes
- Physique
- Enseignement scientifique
- Littérature anglaise
- Espagnol
- Philosophie
- Géographie
- Histoire
- Enseignement moral et civique (EMC)

## API Gemini

Le modèle par défaut est `gemini-3.8-flash`, indiqué comme stable dans la documentation officielle des modèles Gemini au 24 octobre 2026. Le modèle peut être modifié depuis les paramètres si la disponibilité ou le nom de modèle change. Voir la [documentation des modèles Gemini](https://ai.google.dev/gemini-api/docs/models).

La clé est enregistrée dans `chrome.storage.local`, sur le profil du navigateur de cet appareil. C'est pratique pour une extension personnelle, mais ce stockage n'est pas équivalent à un coffre-fort : une personne qui a accès au profil ou aux outils de développement du navigateur peut potentiellement l'extraire. N'ajoute jamais ta clé aux fichiers du dépôt GitHub.

Les requêtes envoient d'abord le titre. Si Gemini demande davantage de contexte, l'extension tente de récupérer la description et une transcription disponible. Les informations récupérées et la justification sont transmises à Gemini pour la décision de recours.

## Assets des intégrales

Les dossiers `1_Enonces/` et `2_Resolutions/` contiennent les PDF source; `assets/exercises/` et `assets/solutions/` contiennent leurs rendus PNG utilisés par l'interface. Les images sont numérotées de `001.png` à `100.png`.

## Limites et comportement de sécurité

- La classification automatique dépend de Gemini et n'est pas infaillible.
- Les appels API en échec, une clé absente ou une classification ambiguë entraînent un refus d'accès (fail closed).
- Le blocage agit sur la navigation du navigateur et ajoute un écran de protection immédiat, mais aucune extension installée sur un navigateur contrôlé par l'utilisateur ne peut garantir une impossibilité absolue de contournement via désactivation de l'extension ou un autre navigateur.
- L'extension est prévue pour être installée dans Arc; les API utilisées sont celles des extensions Chromium et peuvent également être reconnues par d'autres navigateurs compatibles.
